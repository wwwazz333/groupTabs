import { Folder, folderList } from './folder.js';
import { getCurrentWindowTabs, switchTo } from './tabs.js';

function updateTabList() {
	getCurrentWindowTabs().then((tabs) => {
		let tabsList = document.getElementById('tabs-list');
		let currentTabs = document.createDocumentFragment();

		tabsList.textContent = '';
		Folder.loadFolders(tabs)


		for (let tab of tabs) {
			if (!Folder.anyTabContains(tab, folderList)) {
				folderList[0].addTab(tab);
			}
		}
		for (let folder of folderList) {
			var folderElement = folder.createFolderElement()
			currentTabs.appendChild(folderElement)
			if (folder.unroll) {
				folder.unrollChilds(folderElement)
			}
		}

		tabsList.appendChild(currentTabs);
		showAndHideTabBis()
	});
}


document.addEventListener("DOMContentLoaded", updateTabList)



document.getElementById('resetBtn').addEventListener('click', () => {
	for (let folder of folderList) {
		folder.showTabs()
	}
	// localStorage.clear()
	updateTabList()
})
document.getElementById('infoBtn').addEventListener('click', () => {
	for (let folder of folderList) {
		console.log(folder.name + " a " + folder.tabList.length);
		for (let tab of folder.tabList) {
			console.log("\t" + tab.title);
		}
	}
	console.log("Tout");
	getCurrentWindowTabs().then((tabs) => {
		for (let tab of tabs) {
			console.log("\t" + tab.title);
		}
	})
	updateTabList()
})


/*####################################ADD FOLDER####################################*/
function folderNameValide(folderName) {
	if (folderList == "" || Folder.getFolderOfName(folderName) != null) {
		return false
	}
	return true
}
function addFolder() {
	var folderName = document.getElementById("newFolderName").value
	folderName = folderName.trim()
	if (folderNameValide(folderName)) {
		var folder = new Folder("inconnue")
		folder.name = folderName
		folderList.push(folder)
		Folder.saveFolders()
		updateTabList()
	} else {
		alert("Le nom du dossier est invalide (nom interdit : un nom vide, un nom déjà existant et \"default\"")
	}

}
document.getElementById('addBtn').addEventListener('click', addFolder)



/*####################################ROLL AND UNROLL & SWITCH TAB####################################*/
document.addEventListener("click", (active) => {

	if (active.target.classList.contains('switch-tabs')) {//switch tab
		var tabId = +active.target.getAttribute('href')
		switchTo(tabId)
	}

	else if (active.target.classList.contains('switch-tabs-fold')) {//roll & unroll
		var foldId = active.target.getAttribute('href')

		for (let folder of folderList) {
			if (folder.id == foldId) {
				if (!folder.unroll) {
					folder.unrollChilds(active.target)
					// folder.showTabs()
				} else {
					folder.rollChilds(active.target);
					// folder.hideTabs()
				}
			}
		}
	}

	updateTabList()

	active.preventDefault();
});

function showAndHideTab(folderSelected) {
	for (let folder of folderList) {
		if (folder.id != folderSelected.id) {
			console.log("hide")
			folder.hideTabs()
		}
		else {
			console.log("show")
			folder.showTabs()
		}
	}
}
function showAndHideTabBis() {
	for (let folder of folderList) {
		if (folder.unroll) {
			folder.showTabs()
			console.log("showning : " + folder.name);
		}
		else {
			folder.hideTabs()
			console.log("hiding : " + folder.name);
		}
	}
}

/*####################################DRAG IN FOLDER####################################*/
var targetDropingFolderName = null


function moveTabFromTo(tabId, src, dst) {
	src.moveTabTo(tabId, dst)
	Folder.saveFolders()
	updateTabList()
}

document.addEventListener("dragend", (active) => {
	if (active.target.classList.contains('switch-tabs') && targetDropingFolderName) {
		var dragedId = +active.target.getAttribute('href')

		var folderSrc = Folder.getFolderWithTab(dragedId)
		var folderDst = Folder.getFolderOfName(targetDropingFolderName)
		if (folderSrc && folderDst) {
			moveTabFromTo(dragedId, folderSrc, folderDst)
		}
	}
});
document.addEventListener("dragenter", (active) => {
	if (active.target.classList.contains('switch-tabs-fold')) {
		targetDropingFolderName = active.target.getAttribute('id')
		console.log(active.target.getAttribute('id'));
	} else {
		targetDropingFolderName = null
	}
});
