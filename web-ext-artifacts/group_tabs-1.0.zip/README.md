# function
hide() and show() are only avalaible on firefox since 61 version

faire en sorte que si on veut on puisse save le dossier d'onglet dans un dossier de favoris.



à faire :
- mettre les tab qui sont pas dans un folder dans un default folder.
